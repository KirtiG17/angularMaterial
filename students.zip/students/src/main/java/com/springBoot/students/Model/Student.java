package com.springBoot.students.Model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "student")
public class Student {
	@Id ObjectId databaseId;
	int id;
	String fullName;
	String emailId;
	Double contactNumber;
	int rank;
	String desc;
	
	public Student() {
		
	}
	
	public Student(int id, String fullName, String emailId, Double contactNumber,int rank, String desc) {
		this.id = id;
		this.fullName = fullName;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
		this.rank = rank;
		this.desc = desc;
	}
	
	
	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Double getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Double contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
	

}
