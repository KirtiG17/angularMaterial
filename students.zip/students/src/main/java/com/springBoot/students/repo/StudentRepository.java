package com.springBoot.students.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.springBoot.students.Model.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

}
