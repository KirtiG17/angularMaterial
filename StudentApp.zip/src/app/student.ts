export class Student {
    id: number;
    fullName: string;
    emailId:string;
    contactNumber:number;
    rank:number;
    desc:string;
}
